PONG 0.2.0

This is me messing around with Python and seeing if you can make Pong within the Python shell (turns out you can)
This works on Windows and not Linux because I'm too lazy to use the pathlib module
pong.py is the game itself - keyboard is the keyboard module, no touchies
I wanted to make it as standalone as possible. Turns out it's hard to get user input without the keyboard module :(

Editing the settings:
-> Use ESC to exit settings
-> Select an option using the arrow keys and press enter to begin editing
-> Separate multiple values with a comma and a space (e.g. a, b, c, d)
-> Press enter to confirm changes