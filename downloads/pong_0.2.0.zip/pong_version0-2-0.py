import subprocess, sys, time, copy, json, math, getpass, random
sys.path.insert(0, r".")
import keyboard

subprocess.call("", shell=True)
def delete_last_lines(n=1):
    for _ in range(n):
        sys.stdout.write("\033[F")
        sys.stdout.write("\033[K")

class Paddle:
    def __init__(self, height, topx, type):
        self.height = height
        self.topx = topx
        self.bottomx = 0
        self.type = type #type can be "left" or "right"
        self.score = 0
    def set_bottomx(self):
        self.bottomx = self.topx + self.height - 1

class Ball:
    def __init__(self, startx, starty, size, startspeed):
        self.x = startx
        self.startx = startx
        self.y = starty
        self.starty = starty
        self.size = size #in terms of rows and columns (it will be a square)
        self.speed = startspeed #units travelled per game loop. one unit is the distance from one column to the next
        self.startspeed = startspeed
        self.direction = random.randint(30, 60) * random.choice([-1, 1]) * 2.25 #in bearings. i.e. 0 is facing north, 90 is facing east
        self.hits = 0

class Cursor:
    def __init__(self, starty):
        self.y = starty
        self.starty = starty
        self.state = "move" #can be "move" or "change"

def presentify(back, *grids): #the order of the grids specifies the drawing order
    output = []
    for n in range(len(grids)):
        if n == 0:
            output = grids[n]
        else:
            for m in range(len(grids[n])): #each 2-d list
                for b in range(len(grids[n][m])): #each row
                    if grids[n][m][b] == back:
                        pass
                    else:
                        output[m][b] = grids[n][m][b]
    #output now stores the combined grids at this point in the code
    poutput = [] #prepared output (as you can see I am great at naming variables)
    for x in range(len(output)):
        poutput.append("".join(output[x]))
    return "".join(poutput)

gamemode = ""
usercursor = Cursor(0)
settingssize = (6, 3) #(y, x) format: 4 options, 2 rows for title, 3 columns (one for selecting, one for displaying the option, one for entering)
settingslist = []
fps = 45

options = {"gridsize": {"y": 25, "x": 100}, "background": " ", "paddlesize": 5, "speed": 1.0}
showoptions = [f"Grid size: Rows - {options['gridsize']['y']}, Columns - {options['gridsize']['x']}", f"Background: \"{options['background']}\"", f"Paddle size: {options['paddlesize']}", f"Speed of ball: {options['speed']}"]

def update_showoptions():
    global options
    global showoptions
    showoptions = [f"Grid size: Rows - {options['gridsize']['y']}, Columns - {options['gridsize']['x']}", f"Background: \"{options['background']}\"", f"Paddle size: {options['paddlesize']}", f"Speed of ball: {options['speed']}"]

def update_settingslist():
    global settingslist
    settingslist = []
    for t in range(settingssize[0] - 2): #draws settingslist
        innerlist = []
        for u in range(settingssize[1]):
            if u == 0:
                innerlist.append(" ")
            elif u == 1:
                innerlist.append(showoptions[t])
            elif u == 2:
                innerlist.append("")
        innerlist.append("\n")
        settingslist.append(innerlist)

start = time.time()
cooldown = 0.12
inputted = []
newinfo = ""
currentgrid = []

def check_keypress(mode):
    global gamemode
    global inputted
    global newinfo
    global currentgrid
    if mode == "settings":
        global start
        if time.time() - start > cooldown:
            if keyboard.is_pressed("up") and usercursor.y > 0:
                usercursor.y -= 1
                start = time.time()
            if keyboard.is_pressed("down") and usercursor.y < settingssize[0] - 3:
                usercursor.y += 1
                start = time.time()
            if keyboard.is_pressed("enter"):
                if usercursor.state == "change":
                    usercursor.state = "move"
                else:
                    usercursor.state = "change"
                start = time.time()
            if keyboard.is_pressed("esc"):
                gamemode = ""
            if usercursor.state == "change":
                try:
                    if not currentgrid[usercursor.y][2]:
                        pass
                    else:
                        character = keyboard.read_key()
                        if character == "enter":
                            time.sleep(0.05)
                            character = keyboard.read_key()
                            if character == "enter":
                                usercursor.state = "move"
                                newinfo = "".join(inputted)
                                handle_info(newinfo)
                                inputted = []
                            else:
                                pass
                        elif character == "backspace":
                            try:
                                inputted.pop()
                            except:
                                pass
                        elif character == "space":
                            inputted.append(" ")
                        elif len(character) == 1:
                            inputted.append(character)
                        start = time.time()
                except:
                    pass

    elif mode == "game":
        if keyboard.is_pressed("d") and paddle1.bottomx < grid[0] - 2: #down
            paddle1.topx += 1
            paddle1.set_bottomx()
        if keyboard.is_pressed("e") and paddle1.topx > 1: #up
            paddle1.topx -= 1
            paddle1.set_bottomx()
        if keyboard.is_pressed("l") and paddle2.bottomx < grid[0] - 2:
            paddle2.topx += 1
            paddle2.set_bottomx()
        if keyboard.is_pressed("o") and paddle2.topx > 1:
            paddle2.topx -= 1
            paddle2.set_bottomx()
        if keyboard.is_pressed("h"):
            draw()
            print("Quit game.")
            print(f"Final score:\n\u001b[31m{paddle1.score} - {paddle2.score}")
            print("\u001b[0mPress enter to exit.")
            keyboard.wait("enter")
            sys.exit()
        if keyboard.is_pressed("b"):
            draw()
            print("Paused. Press y to continue.")
            while True:
                if keyboard.is_pressed("y"):
                    print("3...")
                    time.sleep(1)
                    print("2...")
                    time.sleep(1)
                    print("1...")
                    time.sleep(1)
                    break

def handle_info(info):
    if usercursor.y == 0:
        try:
            info = info.split(", ")
            options["gridsize"]["y"] = int(info[0])
            options["gridsize"]["x"] = int(info[-1])
        except:
            pass
    elif usercursor.y == 1:
        try:
            options["background"] = info
        except:
            pass
    elif usercursor.y == 2:
        try:
            options["paddlesize"] = int(info)
        except:
            pass
    elif usercursor.y == 3:
        try:
            options["speed"] = float(info)
        except:
            pass
    update_showoptions()

def generate_settings():
    update_settingslist()
    gropy = json.loads(json.dumps(settingslist))
    try:
        gropy[usercursor.y][0] = "■"
    except:
        pass
    if usercursor.state == "change":
        gropy[usercursor.y][2] = " \u001b[35;1mEnter new settings:\u001b[0m " + "".join(inputted)
    else:
        try:
            gropy[usercursor.y][2] = ""
        except:
            pass
    return gropy

def welcome_message():
    print('''\u001b[44;1m┌────┐
│Pong│\u001b[0m made by bowen
\u001b[44;1m└────┘\u001b[0m''')
    print("\u001b[4mVersion 0.2.0\u001b[0m")
    print("\u001b[36;1mPlayer 1 controls: e to move up, d to move down\u001b[0m\n\u001b[33;1mPlayer 2 controls: o to move up, l to move down\u001b[0m")
    print("\u001b[37;1mh to quit game, b to pause game\u001b[0m")
    print("\u001b[33m\u001b[1mPress enter to begin or press # to modify game settings.\u001b[0m")

def update_settings():
    check_keypress("settings")

def draw_settings():
    global currentgrid
    currentgrid = generate_settings()
    print("\u001b[4m\u001b[47;1mSettings\u001b[0m")
    print("\u001b[33;1m\u001b[1mConsult readme.txt for help on how to change the settings.\u001b[0m")
    print(presentify("", generate_settings()))

def settings(): #settings loop
    while True:
        update_settings()
        draw_settings()
        time.sleep(1/20)
        delete_last_lines(settingssize[0] + 1)
        if gamemode != "settings":
            break

while True: #menu loop
    welcome_message()
    while True:
        if keyboard.is_pressed("enter"):
            gamemode = "game"
            break
        if keyboard.is_pressed("#"):
            gamemode = "settings"
            break
    if gamemode == "game":
        break
    elif gamemode == "settings":
        delete_last_lines(8)
        settings()

grid = (options["gridsize"]["y"], options["gridsize"]["x"]) #25 lines, 100 columns i.e. (y, x)
gridlist = []   #note that the grid is in reverse order.
background = options["background"] #background of grid (i.e. non-paddle/ball spaces)

paddle1 = Paddle(options["paddlesize"], 2, "left")
paddle1.set_bottomx()
paddle2 = Paddle(options["paddlesize"], 2, "right")
paddle2.set_bottomx()
gridball = Ball(49, 12, 1, options["speed"])

for e in range(grid[0]): #draws gridlist
    innerlist = []
    for f in range(grid[1]):
        if e == 0:
            if f == 0:
                innerlist.append("╒")
            elif f == grid[1] - 1:
                innerlist.append("╕")
            else:
                innerlist.append("═")
        elif e == grid[0] - 1:
            if f == 0:
                innerlist.append("╘")
            elif f == grid[1] - 1:
                innerlist.append("╛")
            else:
                innerlist.append("═")
        else:
            if f == 0 or f == grid[1] - 1:
                innerlist.append("│")
            else:
                innerlist.append(background)
    innerlist.append("\n")
    gridlist.append(innerlist)

def move_paddle(location, paddle): #returns 2-dimensional list. needs to be rejoined to be printed
    if location <= grid[0] - paddle.height:
        gropy = json.loads(json.dumps(gridlist)) #deepcopy is slow! may need optimisation
        finalgrid = []                           #-- update: now using json dumping and loading. copy still kept imported just in case
        for i in range(paddle.height):
            if paddle.type == "left":
                gropy[(i+location)][1] = "║"
            elif paddle.type == "right":
                gropy[(i+location)][-3] = "║"
        return gropy

def move_ball(ball):
    gropy = json.loads(json.dumps(gridlist))
    gropy[math.floor(ball.y)][math.floor(ball.x)] = "■"
    return gropy

def update_ball(ball):
    ball.speed = ball.startspeed * ((ball.hits + 1) ** (1/3))
    if (ball.x <= 2 and ball.x > 0) and (ball.y <= paddle1.bottomx and ball.y >= paddle1.topx) or (ball.x <= grid[1] - 1 and ball.x >= grid[1] - 3) and (ball.y <= paddle2.bottomx and ball.y >= paddle2.topx):
        ball.direction = 360 - ball.direction #hit paddle
        ball.hits += 1

    if ball.y <= 1 or ball.y >= grid[0] - 2:
        ball.direction = 180 - ball.direction #hit top/bottom wall

    if ball.x >= -1 and ball.x <= grid[1]:
        ball.x += 1/2 * ball.speed * math.sin(math.radians(ball.direction)) #move ball in direction
    if ball.y >= -1 and ball.y <= grid[0]:
        ball.y -= 1/2 * ball.speed * math.cos(math.radians(ball.direction)) #halved to improve accuracy.


    if ball.x <= 0 or ball.x >= grid[1]: #passed past paddle
        if ball.x <= 0:
            paddle2.score += 1
        elif ball.x >= grid[1]:
            paddle1.score += 1
        ball.x = ball.startx
        ball.y = ball.starty
        ball.speed = ball.startspeed
        ball.direction = random.randint(30, 60) * random.choice([-1, 1]) * 2.25
        ball.hits = 0

def show_score():
    gropy = json.loads(json.dumps(gridlist))
    indent = math.floor(grid[1]/8)
    gropy[2][indent] = "\u001b[32m" + str(paddle1.score)[0] + "\u001b[0m"
    gropy[2][-1*indent] = "\u001b[33m" + str(paddle2.score)[0] + "\u001b[0m"
    try:
        gropy[2][indent + 1] = "\u001b[32m" + str(paddle1.score)[1] + "\u001b[0m"
    except:
        pass
    try:
        gropy[2][-1*indent + 1] = "\u001b[33m" + str(paddle2.score)[1] + "\u001b[0m"
    except:
        pass
    try:
        gropy[2][indent + 2] = "\u001b[32m" + str(paddle1.score)[2] + "\u001b[0m"
    except:
        pass
    try:
        gropy[2][-1*indent + 2] = "\u001b[33m" + str(paddle2.score)[2] + "\u001b[0m"
    except:
        pass
    return gropy

def update():
    check_keypress("game")
    #uncomment below to test coordinates
    #print(f"direction: {gridball.direction}")
    update_ball(gridball)
    update_ball(gridball) #updated twice in order to improve accuracy - ball cannot teleport through paddles

def draw():
    show = presentify(background, move_paddle(paddle1.topx, paddle1), move_paddle(paddle2.topx, paddle2), move_ball(gridball), show_score())
    print(show)

while True: #game loop
    update()
    draw()
    time.sleep(1/fps)
    delete_last_lines(2*grid[0])
