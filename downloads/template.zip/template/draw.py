"""
Defines the drawing process. Call draw() to call the drawing process.
Draws the grid (area in which the game is set - the viewing window) and menus,
scores, etc... everything to be shown, really. Some basic code is here in order
to assist with the process.
All variables are defined in config.py and can be updated in there.
"""

import config


def generate_grid(grid, background, *args, **kwargs):
    """Creates basic grid.

    All grids begin life here!
    """
    formatted_grid = []
    for x_unit in range(grid[0]):
        formatted_grid_row = []
        for y_unit in range(grid[1]):
            formatted_grid_row.append(background)
        formatted_grid.append(formatted_grid_row)
    return formatted_grid


def layer_grids(back, *grids):
    """Layers the grids passed as parameters.

    The order of the grids defines the drawing order.
    Note that all grids passed must be 2-d grids.
    """
    output = []
    for n in range(len(grids)):
        if n == 0:
            output = grids[n]
        else:
            for m in range(len(grids[n])):  # each 2-d list
                for b in range(len(grids[n][m])):   # each row
                    if grids[n][m][b] == back:
                        pass
                    else:
                        output[m][b] = grids[n][m][b]
    return output


def append_line_breaks(grid):
    """Appends line breaks to end of each grid line.

    Does what it says.
    """
    for row in grid:
        row.append("\n")
    return grid


def show(grid):
    """"Flattens" the grid, ready for printing.

    Same effect as .join()ing the grid twice.
    """
    grid = ["".join(row) for row in grid]
    return "".join(grid)


def additions(grid, *args, **kwargs):  # modify this function to change the
    # other additional functions...    # look of the grid
    grid = append_line_breaks(grid)
    return grid


def create_grid():
    """Puts together all of the grids and the modifications.

    Returns a grid.
    """
    formatted_grid = generate_grid(config.GRID, config.BACKGROUND)
    modified_grid = additions(formatted_grid)
    return modified_grid


def draw():
    """Main draw function. Call this to display the finalised grid or any other
    things to be drawn.

    Define the variables used in draw.py for the draw() function in config.py.
    """
    print(show(create_grid()))
