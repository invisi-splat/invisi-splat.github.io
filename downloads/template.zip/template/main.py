"""
Boilerplate template for a python game like the pong game that I made.
Edit the update(), draw() and delete() functions to modify the game behaviour.
Global variabes are stored in config.py and can be updated within the program.
If you're feeling frisky you can totally change the main.py code. Don't break
anything!
The keyboard package is included here because... how else are you going to
recieve user input? Edit it at your own risk. Personally I don't.
All code written is hopefully PEP8 compliant. Hopefully.
"""

from update import update
from draw import draw
from delete import delete
import config  # include if necessary. delete if not.


def mainloop():
    while True:
        update()
        draw()
        delete()


mainloop()
