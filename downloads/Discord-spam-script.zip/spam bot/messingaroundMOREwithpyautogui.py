import pyautogui, keyboard, time, re
print('Press ALT+Backspace to start, ALT+9 then ALT+0 to quit.')
i = 0
pause = 0
main = True
script = open("beemoviescript.txt", "r")
script = script.read()

#modifies script
script = re.sub(r"\bO(?=[aeiou](?!t|r|ch))", "C", script)
scriptList = re.split(r"(?<=[.\-!])\s", script)
scriptList = list(filter(("-").__ne__, scriptList))

messagelist = scriptList

while main == True:
    go = False
    while go == False:
        if keyboard.is_pressed("alt+backspace"):
            go = True
        elif keyboard.is_pressed("alt+0"):
            main = False
            break
    if main == True:
        try:
            messageboxlocation = pyautogui.locateCenterOnScreen("imagetofind.jpg", confidence=0.5)
            while go == True:
                if keyboard.is_pressed("alt+9"):
                    go = False
                else:
                    if pause == 6:
                        time.sleep(1)
                        pause = 0
                    else:
                        time.sleep(0.6)
                        pause += 1
                    pyautogui.click(messageboxlocation)
                    pyautogui.typewrite(messagelist[i])
                    pyautogui.press("enter")
                    if i == (len(messagelist) - 1):
                        i = 0
                    else:
                        i += 1
        except TypeError:
            print("Not found.")
